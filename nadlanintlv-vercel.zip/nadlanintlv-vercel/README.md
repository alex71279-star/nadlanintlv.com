# NADLAN IN TLV — Vercel Ready Website

גרסה זו מוכנה להעלאה ל־Vercel ולחיבור לדומיין `nadlanintlv.com`.

## מה כלול
- אתר תדמיתי פרימיום בשחור וזהב
- עברית / אנגלית / צרפתית / רוסית
- WhatsApp מחובר ל־`+972 50-695-3766`
- Email: `NadlanTLV@hotmail.com`
- אזור תושבי חוץ ומשקיעים
- מחשבון תשואה בסיסי
- פילטר נכסים
- מפת שכונות אינטראקטיבית
- אזור SEO/מאמרים
- Schema.org בסיסי לנדל״ן
- `robots.txt` ו־`sitemap.xml`
- `vercel.json` עם clean URLs ו־security headers

## העלאה ל־Vercel — הדרך הכי פשוטה
1. היכנס ל־https://vercel.com ופתח חשבון.
2. בחר **Add New Project**.
3. העלה את תיקיית הפרויקט או חבר GitHub repository.
4. Framework Preset: בחר **Other** או השאר ברירת מחדל.
5. Build Command: אפשר להשאיר ריק.
6. Output Directory: אפשר להשאיר ריק.
7. לחץ **Deploy**.

## חיבור הדומיין nadlanintlv.com
אחרי שהאתר עלה ל־Vercel:
1. כנס לפרויקט ב־Vercel.
2. עבור ל־Settings → Domains.
3. הוסף `nadlanintlv.com` וגם `www.nadlanintlv.com`.
4. Vercel יציג לך רשומות DNS להוסיף אצל ספק הדומיין.
5. אצל ספק הדומיין הוסף בדרך כלל:
   - A record ל־`@` לפי ה-IP ש־Vercel נותן.
   - CNAME ל־`www` שמצביע לכתובת ש־Vercel נותן.
6. המתן עד שהסטטוס ב־Vercel הופך ל־Valid.
7. HTTPS מופעל אוטומטית.

## מה כדאי להחליף בהמשך
- תמונות אמיתיות או מורשות לנכסים.
- נכסים אמיתיים במקום נכסי דמו.
- המלצות לקוחות אמיתיות.
- קישור Calendly/Zoom.
- חיבור Google Analytics ו־Google Search Console.
- מייל עסקי מקצועי כמו `info@nadlanintlv.com`.

## הערה משפטית
המידע באתר כללי בלבד ואינו מהווה ייעוץ משפטי, פיננסי או מיסוי.
